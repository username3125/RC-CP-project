// Tags to search
const tags = ["중국어", "일본어", "물리학", "천문학", "프로그래밍", "역사", "경제학", "심리학", "사회학", "생물학", "철학"];

// Function to perform the search
function searchTags() {
    const searchInput = document.getElementById("tag-search-input").value.toLowerCase(); // Convert search input to lowercase
    const searchResults = document.getElementById("search-results");
    searchResults.innerHTML = ""; // Clear previous search results

    for (const tag of tags) {
        if (tag.toLowerCase().includes(searchInput)) { // Case-insensitive search
            const resultItem = document.createElement("p");
            resultItem.textContent = tag;
            searchResults.appendChild(resultItem);
        }
    }
}

// Add event listener to the search button
const searchButton = document.getElementById("search-button");
searchButton.addEventListener("click", searchTags);

// Perform the search when Enter key is pressed in the search input
const searchInput = document.getElementById("tag-search-input");
searchInput.addEventListener("keyup", function(event) {
    if (event.key === "Enter") {
        searchTags();
    }
});

